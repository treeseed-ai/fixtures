# Developer

The developer book is the quickest route from curiosity to productive local changes in the TreeSeed package and fixture.

## Content authoring

---
title: Content authoring
sidebar:
  order: 1
schemaVersion: treeseed.knowledge-page/v1
id: fixture.developer.content.content-authoring
bookId: fixture-book-developer
slug: content/content-authoring
summary: How fixture content is organized so contributors can update the example
  site without guesswork.
status: published
visibility: public
order: 10
tags: []
contributors: []
relatedBookIds: []
relatedKnowledgeIds: []
relatedNoteIds: []
relatedQuestionIds: []
relatedObjectiveIds: []
relatedProposalIds: []
relatedDecisionIds: []
capabilityIds: []
routePatterns: []
resourceTypes:
  - fixture-knowledge
actionIds: []
keywords: []
documentationUrls: []
---

The fixture is structured by content role. That makes it easier to change one kind of surface without hunting through unrelated files. When in doubt, start from the manifest, then edit the collection the page is actually rendering.


## Developer

---
title: Developer
schemaVersion: treeseed.knowledge-page/v1
id: fixture.developer.index
bookId: fixture-book-developer
slug: index
summary: Local workflow and authoring guidance for working inside a TreeSeed repo.
status: published
visibility: public
order: 20
tags: []
contributors: []
relatedBookIds: []
relatedKnowledgeIds: []
relatedNoteIds: []
relatedQuestionIds: []
relatedObjectiveIds: []
relatedProposalIds: []
relatedDecisionIds: []
capabilityIds: []
routePatterns: []
resourceTypes:
  - fixture-knowledge
actionIds: []
keywords: []
documentationUrls: []
---

The developer book is for contributors who want to edit the package or fixture directly. It keeps the workflow practical: install, verify, inspect the fixture, and make one coherent change at a time.


## Verification loop

---
title: Verification loop
sidebar:
  order: 1
schemaVersion: treeseed.knowledge-page/v1
id: fixture.developer.verification.verification-loop
bookId: fixture-book-developer
slug: verification/verification-loop
summary: How the fixture participates in the package verification chain.
status: published
visibility: public
order: 30
tags: []
contributors: []
relatedBookIds: []
relatedKnowledgeIds: []
relatedNoteIds: []
relatedQuestionIds: []
relatedObjectiveIds: []
relatedProposalIds: []
relatedDecisionIds: []
capabilityIds: []
routePatterns: []
resourceTypes:
  - fixture-knowledge
actionIds: []
keywords: []
documentationUrls: []
---

The fixture is part of verification, not an optional demo. `check`, `build`, and smoke validation all depend on it staying coherent. If a change breaks the fixture, that is usually a package usability signal, not just a content problem.


## Local workflow

---
title: Local workflow
sidebar:
  order: 1
schemaVersion: treeseed.knowledge-page/v1
id: fixture.developer.workflow.local-workflow
bookId: fixture-book-developer
slug: workflow/local-workflow
summary: The shortest loop for making and verifying a TreeSeed change.
status: published
visibility: public
order: 40
tags: []
contributors: []
relatedBookIds: []
relatedKnowledgeIds: []
relatedNoteIds: []
relatedQuestionIds: []
relatedObjectiveIds: []
relatedProposalIds: []
relatedDecisionIds: []
capabilityIds: []
routePatterns: []
resourceTypes:
  - fixture-knowledge
actionIds: []
keywords: []
documentationUrls: []
---

The normal local loop is:

1. install dependencies
2. run package verification
3. inspect the fixture for the surface you changed
4. tighten tests or docs if the change affects contributor understanding

