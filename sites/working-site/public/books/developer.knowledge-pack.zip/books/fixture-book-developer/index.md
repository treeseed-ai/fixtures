---
title: Developer
schemaVersion: treeseed.knowledge-page/v1
id: fixture.developer.index
bookId: fixture-book-developer
slug: index
summary: Local workflow and authoring guidance for working inside a TreeSeed repo.
status: published
visibility: public
order: 20
tags: []
contributors: []
relatedBookIds: []
relatedKnowledgeIds: []
relatedNoteIds: []
relatedQuestionIds: []
relatedObjectiveIds: []
relatedProposalIds: []
relatedDecisionIds: []
capabilityIds: []
routePatterns: []
resourceTypes:
  - fixture-knowledge
actionIds: []
keywords: []
documentationUrls: []
---

The developer book is for contributors who want to edit the package or fixture directly. It keeps the workflow practical: install, verify, inspect the fixture, and make one coherent change at a time.
