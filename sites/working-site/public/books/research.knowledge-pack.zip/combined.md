# Research

The research book explains the reasoning behind TreeSeed’s inquiry surfaces and shows how open questions turn into reusable knowledge over time.

## Keeping inquiry visible

---
title: Keeping inquiry visible
sidebar:
  order: 2
schemaVersion: treeseed.knowledge-page/v1
id: fixture.research.evidence.keeping-inquiry-visible
bookId: fixture-book-research
slug: evidence/keeping-inquiry-visible
summary: Why TreeSeed treats inquiry as part of the site surface instead of
  hidden process.
status: published
visibility: public
order: 10
tags: []
contributors: []
relatedBookIds: []
relatedKnowledgeIds: []
relatedNoteIds: []
relatedQuestionIds: []
relatedObjectiveIds: []
relatedProposalIds: []
relatedDecisionIds: []
capabilityIds: []
routePatterns: []
resourceTypes:
  - fixture-knowledge
actionIds: []
keywords: []
documentationUrls: []
---

Visible inquiry improves collaboration. It helps maintainers explain why a change matters and lets contributors understand the reasoning path behind docs, tests, or runtime adjustments.


## Notes to books

---
title: Notes to books
sidebar:
  order: 1
schemaVersion: treeseed.knowledge-page/v1
id: fixture.research.evidence.notes-to-books
bookId: fixture-book-research
slug: evidence/notes-to-books
summary: How short working notes become longer-lived TreeSeed documentation.
status: published
visibility: public
order: 20
tags: []
contributors: []
relatedBookIds: []
relatedKnowledgeIds: []
relatedNoteIds: []
relatedQuestionIds: []
relatedObjectiveIds: []
relatedProposalIds: []
relatedDecisionIds: []
capabilityIds: []
routePatterns: []
resourceTypes:
  - fixture-knowledge
actionIds: []
keywords: []
documentationUrls: []
---

Notes are the lightest-weight publishing unit. Books are the accumulated form. TreeSeed works best when notes, questions, and objectives can mature into docs without losing their context.


## Research

---
title: Research
schemaVersion: treeseed.knowledge-page/v1
id: fixture.research.index
bookId: fixture-book-research
slug: index
summary: Why TreeSeed keeps inquiry visible as first-class content.
status: published
visibility: public
order: 30
tags: []
contributors: []
relatedBookIds: []
relatedKnowledgeIds: []
relatedNoteIds: []
relatedQuestionIds: []
relatedObjectiveIds: []
relatedProposalIds: []
relatedDecisionIds: []
capabilityIds: []
routePatterns: []
resourceTypes:
  - fixture-knowledge
actionIds: []
keywords: []
documentationUrls: []
---

TreeSeed uses questions and objectives because maintainers need a legible way to connect curiosity, direction, and longer-form documentation. This book focuses on that reasoning layer.


## Objectives as focus

---
title: Objectives as focus
sidebar:
  order: 2
schemaVersion: treeseed.knowledge-page/v1
id: fixture.research.inquiry.objectives-as-focus
bookId: fixture-book-research
slug: inquiry/objectives-as-focus
summary: Why objectives exist alongside questions in the TreeSeed model.
status: published
visibility: public
order: 40
tags: []
contributors: []
relatedBookIds: []
relatedKnowledgeIds: []
relatedNoteIds: []
relatedQuestionIds: []
relatedObjectiveIds: []
relatedProposalIds: []
relatedDecisionIds: []
capabilityIds: []
routePatterns: []
resourceTypes:
  - fixture-knowledge
actionIds: []
keywords: []
documentationUrls: []
---

Objectives narrow the active field. They keep TreeSeed from collecting open questions without also making it clear what the current effort is trying to improve.


## Questions as records

---
title: Questions as records
sidebar:
  order: 1
schemaVersion: treeseed.knowledge-page/v1
id: fixture.research.inquiry.questions-as-records
bookId: fixture-book-research
slug: inquiry/questions-as-records
summary: Why questions are modeled explicitly instead of remaining implicit in
  docs or issue threads.
status: published
visibility: public
order: 50
tags: []
contributors: []
relatedBookIds: []
relatedKnowledgeIds: []
relatedNoteIds: []
relatedQuestionIds: []
relatedObjectiveIds: []
relatedProposalIds: []
relatedDecisionIds: []
capabilityIds: []
routePatterns: []
resourceTypes:
  - fixture-knowledge
actionIds: []
keywords: []
documentationUrls: []
---

Questions give TreeSeed a public place to hold uncertainty. They help contributors see what is still unresolved and which books or objectives those open threads connect to.

