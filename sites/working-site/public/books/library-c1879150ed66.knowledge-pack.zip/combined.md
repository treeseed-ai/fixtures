# Research

The research book explains the reasoning behind TreeSeed’s inquiry surfaces and shows how open questions turn into reusable knowledge over time.

## Keeping inquiry visible

---
title: Keeping inquiry visible
sidebar:
  order: 2
schemaVersion: treeseed.knowledge-page/v1
id: fixture.research.evidence.keeping-inquiry-visible
bookId: fixture-book-research
slug: evidence/keeping-inquiry-visible
summary: Why TreeSeed treats inquiry as part of the site surface instead of
  hidden process.
status: published
visibility: public
order: 10
tags: []
contributors: []
relatedBookIds: []
relatedKnowledgeIds: []
relatedNoteIds: []
relatedQuestionIds: []
relatedObjectiveIds: []
relatedProposalIds: []
relatedDecisionIds: []
capabilityIds: []
routePatterns: []
resourceTypes:
  - fixture-knowledge
actionIds: []
keywords: []
documentationUrls: []
---

Visible inquiry improves collaboration. It helps maintainers explain why a change matters and lets contributors understand the reasoning path behind docs, tests, or runtime adjustments.


## Notes to books

---
title: Notes to books
sidebar:
  order: 1
schemaVersion: treeseed.knowledge-page/v1
id: fixture.research.evidence.notes-to-books
bookId: fixture-book-research
slug: evidence/notes-to-books
summary: How short working notes become longer-lived TreeSeed documentation.
status: published
visibility: public
order: 20
tags: []
contributors: []
relatedBookIds: []
relatedKnowledgeIds: []
relatedNoteIds: []
relatedQuestionIds: []
relatedObjectiveIds: []
relatedProposalIds: []
relatedDecisionIds: []
capabilityIds: []
routePatterns: []
resourceTypes:
  - fixture-knowledge
actionIds: []
keywords: []
documentationUrls: []
---

Notes are the lightest-weight publishing unit. Books are the accumulated form. TreeSeed works best when notes, questions, and objectives can mature into docs without losing their context.


## Research

---
title: Research
schemaVersion: treeseed.knowledge-page/v1
id: fixture.research.index
bookId: fixture-book-research
slug: index
summary: Why TreeSeed keeps inquiry visible as first-class content.
status: published
visibility: public
order: 30
tags: []
contributors: []
relatedBookIds: []
relatedKnowledgeIds: []
relatedNoteIds: []
relatedQuestionIds: []
relatedObjectiveIds: []
relatedProposalIds: []
relatedDecisionIds: []
capabilityIds: []
routePatterns: []
resourceTypes:
  - fixture-knowledge
actionIds: []
keywords: []
documentationUrls: []
---

TreeSeed uses questions and objectives because maintainers need a legible way to connect curiosity, direction, and longer-form documentation. This book focuses on that reasoning layer.


## Objectives as focus

---
title: Objectives as focus
sidebar:
  order: 2
schemaVersion: treeseed.knowledge-page/v1
id: fixture.research.inquiry.objectives-as-focus
bookId: fixture-book-research
slug: inquiry/objectives-as-focus
summary: Why objectives exist alongside questions in the TreeSeed model.
status: published
visibility: public
order: 40
tags: []
contributors: []
relatedBookIds: []
relatedKnowledgeIds: []
relatedNoteIds: []
relatedQuestionIds: []
relatedObjectiveIds: []
relatedProposalIds: []
relatedDecisionIds: []
capabilityIds: []
routePatterns: []
resourceTypes:
  - fixture-knowledge
actionIds: []
keywords: []
documentationUrls: []
---

Objectives narrow the active field. They keep TreeSeed from collecting open questions without also making it clear what the current effort is trying to improve.


## Questions as records

---
title: Questions as records
sidebar:
  order: 1
schemaVersion: treeseed.knowledge-page/v1
id: fixture.research.inquiry.questions-as-records
bookId: fixture-book-research
slug: inquiry/questions-as-records
summary: Why questions are modeled explicitly instead of remaining implicit in
  docs or issue threads.
status: published
visibility: public
order: 50
tags: []
contributors: []
relatedBookIds: []
relatedKnowledgeIds: []
relatedNoteIds: []
relatedQuestionIds: []
relatedObjectiveIds: []
relatedProposalIds: []
relatedDecisionIds: []
capabilityIds: []
routePatterns: []
resourceTypes:
  - fixture-knowledge
actionIds: []
keywords: []
documentationUrls: []
---

Questions give TreeSeed a public place to hold uncertainty. They help contributors see what is still unresolved and which books or objectives those open threads connect to.


# Architecture

The architecture book explains how TreeSeed turns content collections, books, docs, and contributor records into one coherent site.

## Content model

---
title: Content model
sidebar:
  order: 1
schemaVersion: treeseed.knowledge-page/v1
id: fixture.architecture.content.content-model
bookId: fixture-book-architecture
slug: content/content-model
summary: The role of pages, notes, questions, objectives, people, agents, books,
  and docs in TreeSeed.
status: published
visibility: public
order: 10
tags: []
contributors: []
relatedBookIds: []
relatedKnowledgeIds: []
relatedNoteIds: []
relatedQuestionIds: []
relatedObjectiveIds: []
relatedProposalIds: []
relatedDecisionIds: []
capabilityIds: []
routePatterns: []
resourceTypes:
  - fixture-knowledge
actionIds: []
keywords: []
documentationUrls: []
---

TreeSeed uses multiple content collections because they answer different kinds of questions. Pages explain. Notes log. Questions and objectives direct. People and agents show stewardship. Books and docs accumulate knowledge.


## Architecture

---
title: Architecture
schemaVersion: treeseed.knowledge-page/v1
id: fixture.architecture.index
bookId: fixture-book-architecture
slug: index
summary: How TreeSeed turns content collections and workflows into one coherent
  site surface.
status: published
visibility: public
order: 20
tags: []
contributors: []
relatedBookIds: []
relatedKnowledgeIds: []
relatedNoteIds: []
relatedQuestionIds: []
relatedObjectiveIds: []
relatedProposalIds: []
relatedDecisionIds: []
capabilityIds: []
routePatterns: []
resourceTypes:
  - fixture-knowledge
actionIds: []
keywords: []
documentationUrls: []
---

The TreeSeed architecture is intentionally small. Its job is to make content, contributors, workflows, and verification feel connected rather than scattered across unrelated tools.


## Working surface

---
title: Working surface
sidebar:
  order: 1
schemaVersion: treeseed.knowledge-page/v1
id: fixture.architecture.management.working-surface
bookId: fixture-book-architecture
slug: management/working-surface
summary: Why TreeSeed treats management and documentation as one public surface.
status: published
visibility: public
order: 30
tags: []
contributors: []
relatedBookIds: []
relatedKnowledgeIds: []
relatedNoteIds: []
relatedQuestionIds: []
relatedObjectiveIds: []
relatedProposalIds: []
relatedDecisionIds: []
capabilityIds: []
routePatterns: []
resourceTypes:
  - fixture-knowledge
actionIds: []
keywords: []
documentationUrls: []
---

The working surface is the practical center of TreeSeed. It should make ongoing work easy to understand by showing active questions, current objectives, contributor ownership, and the books or docs that hold the durable context.


## Site runtime

---
title: Site runtime
sidebar:
  order: 1
schemaVersion: treeseed.knowledge-page/v1
id: fixture.architecture.runtime.site-runtime
bookId: fixture-book-architecture
slug: runtime/site-runtime
summary: The shared runtime and page surface that power a TreeSeed tenant.
status: published
visibility: public
order: 40
tags: []
contributors: []
relatedBookIds: []
relatedKnowledgeIds: []
relatedNoteIds: []
relatedQuestionIds: []
relatedObjectiveIds: []
relatedProposalIds: []
relatedDecisionIds: []
capabilityIds: []
routePatterns: []
resourceTypes:
  - fixture-knowledge
actionIds: []
keywords: []
documentationUrls: []
---

The site runtime provides shared pages, layouts, styles, and content-driven routes so a tenant can feel consistent without hand-wiring every page from scratch.


## TreeSeed Knowledge

---
title: TreeSeed Knowledge
prev: false
next: false
tableOfContents: false
schemaVersion: treeseed.knowledge-page/v1
id: fixture.architecture.overview
bookId: fixture-book-architecture
slug: overview
summary: TreeSeed documentation organized as small books with shared navigation
  and downloadable exports.
status: published
visibility: public
order: 50
tags: []
contributors: []
relatedBookIds: []
relatedKnowledgeIds: []
relatedNoteIds: []
relatedQuestionIds: []
relatedObjectiveIds: []
relatedProposalIds: []
relatedDecisionIds: []
capabilityIds: []
routePatterns: []
resourceTypes:
  - fixture-knowledge
actionIds: []
keywords: []
documentationUrls: []
---

import { Card, CardGrid } from '@astrojs/starlight/components';

The TreeSeed knowledge library is organized as separate books so contributors can move directly to the level they need: inquiry framing, architecture, local development, or operations.

<CardGrid stagger>
  <Card title="Research" icon="open-book">
    Why TreeSeed models inquiry explicitly. [Open research](/knowledge/research/)
  </Card>

  <Card title="Architecture" icon="open-book">
    How the site, content, and management surfaces fit together. [Open architecture](/knowledge/architecture/)
  </Card>

  <Card title="Developer" icon="seti:txt">
    How to work in the repo and edit the fixture productively. [Open developer](/knowledge/developer/)
  </Card>

  <Card title="Operations" icon="seti:yaml">
    Verification, forms, exports, and deploy-facing guidance. [Open operations](/knowledge/operations/)
  </Card>
</CardGrid>


# Developer

The developer book is the quickest route from curiosity to productive local changes in the TreeSeed package and fixture.

## Content authoring

---
title: Content authoring
sidebar:
  order: 1
schemaVersion: treeseed.knowledge-page/v1
id: fixture.developer.content.content-authoring
bookId: fixture-book-developer
slug: content/content-authoring
summary: How fixture content is organized so contributors can update the example
  site without guesswork.
status: published
visibility: public
order: 10
tags: []
contributors: []
relatedBookIds: []
relatedKnowledgeIds: []
relatedNoteIds: []
relatedQuestionIds: []
relatedObjectiveIds: []
relatedProposalIds: []
relatedDecisionIds: []
capabilityIds: []
routePatterns: []
resourceTypes:
  - fixture-knowledge
actionIds: []
keywords: []
documentationUrls: []
---

The fixture is structured by content role. That makes it easier to change one kind of surface without hunting through unrelated files. When in doubt, start from the manifest, then edit the collection the page is actually rendering.


## Developer

---
title: Developer
schemaVersion: treeseed.knowledge-page/v1
id: fixture.developer.index
bookId: fixture-book-developer
slug: index
summary: Local workflow and authoring guidance for working inside a TreeSeed repo.
status: published
visibility: public
order: 20
tags: []
contributors: []
relatedBookIds: []
relatedKnowledgeIds: []
relatedNoteIds: []
relatedQuestionIds: []
relatedObjectiveIds: []
relatedProposalIds: []
relatedDecisionIds: []
capabilityIds: []
routePatterns: []
resourceTypes:
  - fixture-knowledge
actionIds: []
keywords: []
documentationUrls: []
---

The developer book is for contributors who want to edit the package or fixture directly. It keeps the workflow practical: install, verify, inspect the fixture, and make one coherent change at a time.


## Verification loop

---
title: Verification loop
sidebar:
  order: 1
schemaVersion: treeseed.knowledge-page/v1
id: fixture.developer.verification.verification-loop
bookId: fixture-book-developer
slug: verification/verification-loop
summary: How the fixture participates in the package verification chain.
status: published
visibility: public
order: 30
tags: []
contributors: []
relatedBookIds: []
relatedKnowledgeIds: []
relatedNoteIds: []
relatedQuestionIds: []
relatedObjectiveIds: []
relatedProposalIds: []
relatedDecisionIds: []
capabilityIds: []
routePatterns: []
resourceTypes:
  - fixture-knowledge
actionIds: []
keywords: []
documentationUrls: []
---

The fixture is part of verification, not an optional demo. `check`, `build`, and smoke validation all depend on it staying coherent. If a change breaks the fixture, that is usually a package usability signal, not just a content problem.


## Local workflow

---
title: Local workflow
sidebar:
  order: 1
schemaVersion: treeseed.knowledge-page/v1
id: fixture.developer.workflow.local-workflow
bookId: fixture-book-developer
slug: workflow/local-workflow
summary: The shortest loop for making and verifying a TreeSeed change.
status: published
visibility: public
order: 40
tags: []
contributors: []
relatedBookIds: []
relatedKnowledgeIds: []
relatedNoteIds: []
relatedQuestionIds: []
relatedObjectiveIds: []
relatedProposalIds: []
relatedDecisionIds: []
capabilityIds: []
routePatterns: []
resourceTypes:
  - fixture-knowledge
actionIds: []
keywords: []
documentationUrls: []
---

The normal local loop is:

1. install dependencies
2. run package verification
3. inspect the fixture for the surface you changed
4. tighten tests or docs if the change affects contributor understanding


# Operations

The operations book explains how the fixture is verified, how book exports are generated, and where deploy-facing defaults matter.

## Deploy template

---
title: Deploy template
sidebar:
  order: 1
schemaVersion: treeseed.knowledge-page/v1
id: fixture.operations.deploy.deploy-template
bookId: fixture-book-operations
slug: deploy/deploy-template
summary: What the included deploy workflow template represents for downstream
  TreeSeed sites.
status: published
visibility: public
order: 10
tags: []
contributors: []
relatedBookIds: []
relatedKnowledgeIds: []
relatedNoteIds: []
relatedQuestionIds: []
relatedObjectiveIds: []
relatedProposalIds: []
relatedDecisionIds: []
capabilityIds: []
routePatterns: []
resourceTypes:
  - fixture-knowledge
actionIds: []
keywords: []
documentationUrls: []
---

The deploy template shows the expected CI shape for a TreeSeed tenant. It should stay aligned with the package runtime and secret contract, but it should remain generic enough to fit many downstream sites.


## Forms and routing

---
title: Forms and routing
sidebar:
  order: 1
schemaVersion: treeseed.knowledge-page/v1
id: fixture.operations.forms.forms-and-routing
bookId: fixture-book-operations
slug: forms/forms-and-routing
summary: How contact and subscribe flows behave in the generic TreeSeed fixture.
status: published
visibility: public
order: 20
tags: []
contributors: []
relatedBookIds: []
relatedKnowledgeIds: []
relatedNoteIds: []
relatedQuestionIds: []
relatedObjectiveIds: []
relatedProposalIds: []
relatedDecisionIds: []
capabilityIds: []
routePatterns: []
resourceTypes:
  - fixture-knowledge
actionIds: []
keywords: []
documentationUrls: []
---

The fixture uses generic routing and notification defaults so contributors can inspect forms behavior without inheriting one project’s branding or inbox structure. It exists to validate the flow, not to simulate a production communications system.


## Operations

---
title: Operations
schemaVersion: treeseed.knowledge-page/v1
id: fixture.operations.index
bookId: fixture-book-operations
slug: index
summary: Release checks, forms behavior, and deploy-facing guidance for the
  TreeSeed fixture.
status: published
visibility: public
order: 30
tags: []
contributors: []
relatedBookIds: []
relatedKnowledgeIds: []
relatedNoteIds: []
relatedQuestionIds: []
relatedObjectiveIds: []
relatedProposalIds: []
relatedDecisionIds: []
capabilityIds: []
routePatterns: []
resourceTypes:
  - fixture-knowledge
actionIds: []
keywords: []
documentationUrls: []
---

The operations book keeps the fixture grounded in actual runtime expectations. It explains what verification proves, how forms are routed, and what the deploy template is meant to represent.


## Release checks

---
title: Release checks
sidebar:
  order: 1
schemaVersion: treeseed.knowledge-page/v1
id: fixture.operations.release.release-checks
bookId: fixture-book-operations
slug: release/release-checks
summary: What the TreeSeed verification chain is expected to prove before publishing.
status: published
visibility: public
order: 40
tags: []
contributors: []
relatedBookIds: []
relatedKnowledgeIds: []
relatedNoteIds: []
relatedQuestionIds: []
relatedObjectiveIds: []
relatedProposalIds: []
relatedDecisionIds: []
capabilityIds: []
routePatterns: []
resourceTypes:
  - fixture-knowledge
actionIds: []
keywords: []
documentationUrls: []
---

The release flow should demonstrate that package builds, tests, fixture checks, fixture builds, and packed-install smoke validation all still succeed together. That is the practical contract of the fixture.

