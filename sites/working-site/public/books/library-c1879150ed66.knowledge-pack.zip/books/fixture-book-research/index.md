---
title: Research
schemaVersion: treeseed.knowledge-page/v1
id: fixture.research.index
bookId: fixture-book-research
slug: index
summary: Why TreeSeed keeps inquiry visible as first-class content.
status: published
visibility: public
order: 30
tags: []
contributors: []
relatedBookIds: []
relatedKnowledgeIds: []
relatedNoteIds: []
relatedQuestionIds: []
relatedObjectiveIds: []
relatedProposalIds: []
relatedDecisionIds: []
capabilityIds: []
routePatterns: []
resourceTypes:
  - fixture-knowledge
actionIds: []
keywords: []
documentationUrls: []
---

TreeSeed uses questions and objectives because maintainers need a legible way to connect curiosity, direction, and longer-form documentation. This book focuses on that reasoning layer.
