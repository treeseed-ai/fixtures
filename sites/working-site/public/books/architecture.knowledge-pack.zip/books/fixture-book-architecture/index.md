---
title: Architecture
schemaVersion: treeseed.knowledge-page/v1
id: fixture.architecture.index
bookId: fixture-book-architecture
slug: index
summary: How TreeSeed turns content collections and workflows into one coherent
  site surface.
status: published
visibility: public
order: 20
tags: []
contributors: []
relatedBookIds: []
relatedKnowledgeIds: []
relatedNoteIds: []
relatedQuestionIds: []
relatedObjectiveIds: []
relatedProposalIds: []
relatedDecisionIds: []
capabilityIds: []
routePatterns: []
resourceTypes:
  - fixture-knowledge
actionIds: []
keywords: []
documentationUrls: []
---

The TreeSeed architecture is intentionally small. Its job is to make content, contributors, workflows, and verification feel connected rather than scattered across unrelated tools.
