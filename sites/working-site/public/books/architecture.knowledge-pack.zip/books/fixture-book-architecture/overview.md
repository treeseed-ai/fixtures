---
title: TreeSeed Knowledge
prev: false
next: false
tableOfContents: false
schemaVersion: treeseed.knowledge-page/v1
id: fixture.architecture.overview
bookId: fixture-book-architecture
slug: overview
summary: TreeSeed documentation organized as small books with shared navigation
  and downloadable exports.
status: published
visibility: public
order: 50
tags: []
contributors: []
relatedBookIds: []
relatedKnowledgeIds: []
relatedNoteIds: []
relatedQuestionIds: []
relatedObjectiveIds: []
relatedProposalIds: []
relatedDecisionIds: []
capabilityIds: []
routePatterns: []
resourceTypes:
  - fixture-knowledge
actionIds: []
keywords: []
documentationUrls: []
---

import { Card, CardGrid } from '@astrojs/starlight/components';

The TreeSeed knowledge library is organized as separate books so contributors can move directly to the level they need: inquiry framing, architecture, local development, or operations.

<CardGrid stagger>
  <Card title="Research" icon="open-book">
    Why TreeSeed models inquiry explicitly. [Open research](/knowledge/research/)
  </Card>

  <Card title="Architecture" icon="open-book">
    How the site, content, and management surfaces fit together. [Open architecture](/knowledge/architecture/)
  </Card>

  <Card title="Developer" icon="seti:txt">
    How to work in the repo and edit the fixture productively. [Open developer](/knowledge/developer/)
  </Card>

  <Card title="Operations" icon="seti:yaml">
    Verification, forms, exports, and deploy-facing guidance. [Open operations](/knowledge/operations/)
  </Card>
</CardGrid>
