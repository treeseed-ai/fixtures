# Architecture

The architecture book explains how TreeSeed turns content collections, books, docs, and contributor records into one coherent site.

## Content model

---
title: Content model
sidebar:
  order: 1
schemaVersion: treeseed.knowledge-page/v1
id: fixture.architecture.content.content-model
bookId: fixture-book-architecture
slug: content/content-model
summary: The role of pages, notes, questions, objectives, people, agents, books,
  and docs in TreeSeed.
status: published
visibility: public
order: 10
tags: []
contributors: []
relatedBookIds: []
relatedKnowledgeIds: []
relatedNoteIds: []
relatedQuestionIds: []
relatedObjectiveIds: []
relatedProposalIds: []
relatedDecisionIds: []
capabilityIds: []
routePatterns: []
resourceTypes:
  - fixture-knowledge
actionIds: []
keywords: []
documentationUrls: []
---

TreeSeed uses multiple content collections because they answer different kinds of questions. Pages explain. Notes log. Questions and objectives direct. People and agents show stewardship. Books and docs accumulate knowledge.


## Architecture

---
title: Architecture
schemaVersion: treeseed.knowledge-page/v1
id: fixture.architecture.index
bookId: fixture-book-architecture
slug: index
summary: How TreeSeed turns content collections and workflows into one coherent
  site surface.
status: published
visibility: public
order: 20
tags: []
contributors: []
relatedBookIds: []
relatedKnowledgeIds: []
relatedNoteIds: []
relatedQuestionIds: []
relatedObjectiveIds: []
relatedProposalIds: []
relatedDecisionIds: []
capabilityIds: []
routePatterns: []
resourceTypes:
  - fixture-knowledge
actionIds: []
keywords: []
documentationUrls: []
---

The TreeSeed architecture is intentionally small. Its job is to make content, contributors, workflows, and verification feel connected rather than scattered across unrelated tools.


## Working surface

---
title: Working surface
sidebar:
  order: 1
schemaVersion: treeseed.knowledge-page/v1
id: fixture.architecture.management.working-surface
bookId: fixture-book-architecture
slug: management/working-surface
summary: Why TreeSeed treats management and documentation as one public surface.
status: published
visibility: public
order: 30
tags: []
contributors: []
relatedBookIds: []
relatedKnowledgeIds: []
relatedNoteIds: []
relatedQuestionIds: []
relatedObjectiveIds: []
relatedProposalIds: []
relatedDecisionIds: []
capabilityIds: []
routePatterns: []
resourceTypes:
  - fixture-knowledge
actionIds: []
keywords: []
documentationUrls: []
---

The working surface is the practical center of TreeSeed. It should make ongoing work easy to understand by showing active questions, current objectives, contributor ownership, and the books or docs that hold the durable context.


## Site runtime

---
title: Site runtime
sidebar:
  order: 1
schemaVersion: treeseed.knowledge-page/v1
id: fixture.architecture.runtime.site-runtime
bookId: fixture-book-architecture
slug: runtime/site-runtime
summary: The shared runtime and page surface that power a TreeSeed tenant.
status: published
visibility: public
order: 40
tags: []
contributors: []
relatedBookIds: []
relatedKnowledgeIds: []
relatedNoteIds: []
relatedQuestionIds: []
relatedObjectiveIds: []
relatedProposalIds: []
relatedDecisionIds: []
capabilityIds: []
routePatterns: []
resourceTypes:
  - fixture-knowledge
actionIds: []
keywords: []
documentationUrls: []
---

The site runtime provides shared pages, layouts, styles, and content-driven routes so a tenant can feel consistent without hand-wiring every page from scratch.


## TreeSeed Knowledge

---
title: TreeSeed Knowledge
prev: false
next: false
tableOfContents: false
schemaVersion: treeseed.knowledge-page/v1
id: fixture.architecture.overview
bookId: fixture-book-architecture
slug: overview
summary: TreeSeed documentation organized as small books with shared navigation
  and downloadable exports.
status: published
visibility: public
order: 50
tags: []
contributors: []
relatedBookIds: []
relatedKnowledgeIds: []
relatedNoteIds: []
relatedQuestionIds: []
relatedObjectiveIds: []
relatedProposalIds: []
relatedDecisionIds: []
capabilityIds: []
routePatterns: []
resourceTypes:
  - fixture-knowledge
actionIds: []
keywords: []
documentationUrls: []
---

import { Card, CardGrid } from '@astrojs/starlight/components';

The TreeSeed knowledge library is organized as separate books so contributors can move directly to the level they need: inquiry framing, architecture, local development, or operations.

<CardGrid stagger>
  <Card title="Research" icon="open-book">
    Why TreeSeed models inquiry explicitly. [Open research](/knowledge/research/)
  </Card>

  <Card title="Architecture" icon="open-book">
    How the site, content, and management surfaces fit together. [Open architecture](/knowledge/architecture/)
  </Card>

  <Card title="Developer" icon="seti:txt">
    How to work in the repo and edit the fixture productively. [Open developer](/knowledge/developer/)
  </Card>

  <Card title="Operations" icon="seti:yaml">
    Verification, forms, exports, and deploy-facing guidance. [Open operations](/knowledge/operations/)
  </Card>
</CardGrid>

