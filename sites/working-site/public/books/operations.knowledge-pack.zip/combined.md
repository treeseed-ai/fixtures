# Operations

The operations book explains how the fixture is verified, how book exports are generated, and where deploy-facing defaults matter.

## Deploy template

---
title: Deploy template
sidebar:
  order: 1
schemaVersion: treeseed.knowledge-page/v1
id: fixture.operations.deploy.deploy-template
bookId: fixture-book-operations
slug: deploy/deploy-template
summary: What the included deploy workflow template represents for downstream
  TreeSeed sites.
status: published
visibility: public
order: 10
tags: []
contributors: []
relatedBookIds: []
relatedKnowledgeIds: []
relatedNoteIds: []
relatedQuestionIds: []
relatedObjectiveIds: []
relatedProposalIds: []
relatedDecisionIds: []
capabilityIds: []
routePatterns: []
resourceTypes:
  - fixture-knowledge
actionIds: []
keywords: []
documentationUrls: []
---

The deploy template shows the expected CI shape for a TreeSeed tenant. It should stay aligned with the package runtime and secret contract, but it should remain generic enough to fit many downstream sites.


## Forms and routing

---
title: Forms and routing
sidebar:
  order: 1
schemaVersion: treeseed.knowledge-page/v1
id: fixture.operations.forms.forms-and-routing
bookId: fixture-book-operations
slug: forms/forms-and-routing
summary: How contact and subscribe flows behave in the generic TreeSeed fixture.
status: published
visibility: public
order: 20
tags: []
contributors: []
relatedBookIds: []
relatedKnowledgeIds: []
relatedNoteIds: []
relatedQuestionIds: []
relatedObjectiveIds: []
relatedProposalIds: []
relatedDecisionIds: []
capabilityIds: []
routePatterns: []
resourceTypes:
  - fixture-knowledge
actionIds: []
keywords: []
documentationUrls: []
---

The fixture uses generic routing and notification defaults so contributors can inspect forms behavior without inheriting one project’s branding or inbox structure. It exists to validate the flow, not to simulate a production communications system.


## Operations

---
title: Operations
schemaVersion: treeseed.knowledge-page/v1
id: fixture.operations.index
bookId: fixture-book-operations
slug: index
summary: Release checks, forms behavior, and deploy-facing guidance for the
  TreeSeed fixture.
status: published
visibility: public
order: 30
tags: []
contributors: []
relatedBookIds: []
relatedKnowledgeIds: []
relatedNoteIds: []
relatedQuestionIds: []
relatedObjectiveIds: []
relatedProposalIds: []
relatedDecisionIds: []
capabilityIds: []
routePatterns: []
resourceTypes:
  - fixture-knowledge
actionIds: []
keywords: []
documentationUrls: []
---

The operations book keeps the fixture grounded in actual runtime expectations. It explains what verification proves, how forms are routed, and what the deploy template is meant to represent.


## Release checks

---
title: Release checks
sidebar:
  order: 1
schemaVersion: treeseed.knowledge-page/v1
id: fixture.operations.release.release-checks
bookId: fixture-book-operations
slug: release/release-checks
summary: What the TreeSeed verification chain is expected to prove before publishing.
status: published
visibility: public
order: 40
tags: []
contributors: []
relatedBookIds: []
relatedKnowledgeIds: []
relatedNoteIds: []
relatedQuestionIds: []
relatedObjectiveIds: []
relatedProposalIds: []
relatedDecisionIds: []
capabilityIds: []
routePatterns: []
resourceTypes:
  - fixture-knowledge
actionIds: []
keywords: []
documentationUrls: []
---

The release flow should demonstrate that package builds, tests, fixture checks, fixture builds, and packed-install smoke validation all still succeed together. That is the practical contract of the fixture.

